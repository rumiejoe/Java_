/**
 * Array Dictionary
 *
 * @author Ojorumie Joe-Oka 
 * @version 21st April 2021 
 *
 */
import java.io.*;

public class ArrayDictionary 
{
   private Word [] data;
   private int n;

   /**
    * Reds words from a file and insert into an array 
    *
    * @param f file from which words to be inserted into array are taken
    */
   public ArrayDictionary(String f) throws IOException
   {
      data = new Word[400000];
      Word converter;
      
      BufferedReader br = new BufferedReader(new FileReader(f));      
      String word = br.readLine();
      
      n = 0;
      while (word != null) {
         converter = new Word(word);  
         data[n] = converter;
         word = br.readLine();
         n++;
	   }     
      
      if(n < data.length){
         Word[] temp = new Word[n];
         for(int i = 0; i < temp.length; i++){
            temp[i] = data[i];
         }
         data = temp;
      }
         
      br.close();
      sort();
   }
   
   
   /** 
    * Count the number of anagrams of a word in a list
    * 
    * @param w the Word for which anagram is to be searched 
    * 
    * @return the number of anagrams of w
    */
   public int countAnagrams(Word w)
   {
      int index = binSearch(w);
      int count = 0;
      int i;
      if(binSearch(w) != -1){
         count = 1;
      }else
         return 0;
      
     if(index+1 < data.length && data[index+1].isAnagram(w)){
         i = index+1;
         while(i != 20 && data[i].isAnagram(w)){
            count++;
            i++;
         }
      }
      
      if(index-1 != -1 && data[index-1].isAnagram(w)){
         i = index-1;
         while(i != -1 && data[i].isAnagram(w)){
            count++;
            i--;
         }
      }
      
      return count;   
   }
   
   
   /** 
    * Displays words with 6 or more anagrams 
    */
   public void displayBigAnagramFamilies()
   {
      for(int i = 0; i<data.length; i++){  
         if(countAnagrams(data[i])>=6)
            System.out.println(data[i]); 
      } 
   }
   
   
   /**
    * Displays the first 20 elements in the array.
    */
   public void display()
   {
      for(int i = 0; i<20; i++){
         System.out.println(data[i]);
      }
   }
   
   
   /**
    * sort the array
    */
   private void sort()
   {
      qSort(0,n-1);
   }
   
   
   /**
    * Divides array into two parts,
    * 
    * @param p left pointer in the array 
    * @param r right pointer in the array 
    *
    * @return the point the array was split
    */
    private int partition(int p, int r) { 
      int i,j;
      
      Word k = data[p]; // k= first element in partition 
      Word temp;
      
      i= p-1; // i is our left pointer
      j= r+1; // j is our right pointer
      
      do {
         do { j--; } while (data[j].compareTo(k)>0); // move right pointer 
         do { i++; } while (data[i].compareTo(k)<0); // move left pointer
         if (i<j) { // if the pointers have not crossed then swap
            temp = data[i]; 
            data[i]= data[j];
            data[j]= temp;
         }
      } while (i<j); // stop when i & j have crossed
      
      return j; // j marks the spot where we split the array
   }
   
   
   /**
    * Quicksort the array
    *
    * @param p left pointer in the array 
    * @param r right pointer in the array 
    */
   private void qSort(int p, int r)
   {
      int q; // make sure portion of array we are sorting has more 
             // than one element ...
      if (p < r) {              
         q = partition(p,r); // partition array (splits at q) 
         qSort(p,q); // do quicksort on left part
         qSort(q+1,r); // do quicksort on right part
      }
   }
   
   
   /**
    * Binary search 
    * 
    * @param w the word to be searched for 
    *
    * @return the index of the word searched for, -1 if not found 
    */
   private int binSearch(Word w)
   {
      int l = 0;
      int r = data.length-1;
      if(l>r){
         return -1;
      }
      
      int mid = (l+r)/2;
    
      if (w.compareTo(data[mid]) == 0){
         return mid;
      }else if (w.compareTo(data[mid])<0){
         return binSearch(w,l,mid-1);
      }else{
         return binSearch(w,mid+1,r);
      }
   }
   
   
   /**
    * Helper method for the binary search method 
    * 
    * @param w word to be searched for 
    * @param l the leftmost index of part being searched 
    * @param r the rightmost index of part being searched
    *
    * @return the index of word searched for 
    */
   private int binSearch(Word w, int l, int r)
   {
      if(l>r)
         return -1;
      
      int mid = (l+r)/2;
      
      if(w.compareTo(data[mid]) == 0){
         return mid;  
      }else if(w.compareTo(data[mid]) < 0){
         return binSearch(w,l,mid-1);
      }else{
         return binSearch(w,mid+1,r);
      }
   }
   
   


}
