//Questions 17 - 20

//Question 17
public class ASCIIArt{
   
   private int rows;
   private int columns;
   char [][] pad;
   char colour;
   
   //Question 18
   public ASCIIArt(){
      rows = 30;
      columns = 20;
      for(int i =0; i<rows; i++){
         for(int j =0; j<rows; j++){
            pad[i][j] = ' ';
         }
      }
   }
   
   //Question 19
   public void draw(int r, int c, char ch){
      if(r>=rows||c>=columns && ch != colour){
         return;
      }else{
         pad[r][c] = ch;
      }
   }
   
   //Question 20
   public boolean isDark(){
      int countDark =0;
      int countLight = 0;
      
      for(int i=0; i<rows; i++){
         for(int j=0; j<columns; j++){
            if((pad[i][j] == 'X')||(pad[i][j] == 'B')){
               countDark++;
            }else if((pad[i][j] ==' ')||(pad[i][j] == '.')){
               countLight++;
            } 
         }
      }
      
      if(countDark > countLight)
         return true;
      
      return false;
   }
}