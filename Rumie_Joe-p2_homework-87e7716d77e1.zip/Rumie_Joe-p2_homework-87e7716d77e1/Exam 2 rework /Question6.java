public class Question6{
   
   public static void main(String [] args){
      int ans = count7(717);
      System.out.print(ans);
   }
   
   public static int count7(int n) {
      if(n<7)
         return 0;
      if(n%10==7){
         return 1 + count7(n/10);
      }
      
      return count7(n/10);
   }
}