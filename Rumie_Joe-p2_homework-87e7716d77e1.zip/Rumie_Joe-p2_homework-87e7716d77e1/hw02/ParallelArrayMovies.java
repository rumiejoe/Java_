/**
 * Personal Movie Inventory System.
 *
 * @author  Ojorumie Joe-Oka
 * @version 07 February 2021
 *
 * <p>
 * This is the complete code for the parallel array version of the movie
 * inventory system.
 * </p>
 *
*/

import java.util.Scanner;
import java.io.*;

public class ParallelArrayMovies
{
	public static final String DATAFILE= "../data/movielist.txt";
	public static final int MAXMOVIES= 10000;

	public static void main(String [] args) throws FileNotFoundException
	{
		int choice;						 // user's selection from the menu
		String [] titles= new String[MAXMOVIES];
		String [] genres= new String[MAXMOVIES];
		int [] years= new int[MAXMOVIES];
		int numberOfEntries;

		numberOfEntries= loadMovies(titles,genres,years);
		System.out.println("Number of entries read from data file: "+numberOfEntries);
		do {
			choice= getMenuChoice();
			if (choice==1)
				numberOfEntries= enterMovie(titles,genres,years,numberOfEntries);
			else if (choice==2){
				deleteMovie(titles,genres,years,numberOfEntries);
            numberOfEntries--;
			}else if (choice==3)
				displayAll(titles,genres,years,numberOfEntries);
			else if (choice==4)
				searchByGenre(titles,genres,years,numberOfEntries);
			else if (choice==5)
				searchByTitle(titles,genres,years,numberOfEntries);
			else if (choice==6)
				searchByYear(titles,genres,years,numberOfEntries);
		} while (choice!=0);
      
      saveChanges(titles,genres,years,numberOfEntries);

		System.out.println("\nTHE END");
	}


	/**
	 * Allow user to enter a new movie.
	 *
	 * @param titles array of movie titles
	 * @param genres array of movie genres
	 * @param years array of movie copyright dates
	 * @param n the actual number of movies currently in the array
	 * @return the new movie count
	*/
	public static int enterMovie(String [] titles, String [] genres, int [] years, int n)
	{
		Scanner kb= new Scanner(System.in);
		System.out.print("Enter movie title : ");
		titles[n]= kb.nextLine();
		System.out.print("Enter movie genre: ");
		genres[n]= kb.nextLine();
		System.out.print("Enter year of movie: ");
		years[n]= kb.nextInt();
		kb.nextLine();


		return n+1;
	}




	/**
	 * Load movies from the data file into the arrays
	 *
	 * @param titles array of movie titles
	 * @param genres array of movie genres
	 * @param years array of movie copyright dates
	 * @return the actual number of movies loaded into the arrays
	*/
	public static int loadMovies(String [] titles, String [] genres, int [] years) throws FileNotFoundException
	{
      int numberOfMovies=0;
      int i =0;
      Scanner fIn = new Scanner(new FileInputStream("../data/movielist.txt"));
      
      while(fIn.hasNextLine()){
         titles[i] = fIn.nextLine();
         genres[i] = fIn.nextLine();         
         years[i] = fIn.nextInt();
         fIn.nextLine();
         
         i+=1;
         numberOfMovies+=1;
      }
      
      
      return numberOfMovies;
	}



	/**
	 * Displays all movie information.
	 *
	 * @param titles array of movie titles
	 * @param genres array of movie genres
	 * @param years array of movie copyright dates
	 * @param n the actual number of movies currently in the array
	*/
	public static void displayAll(String [] titles, String [] genres, int [] years, int n)
	{
		int i;
		System.out.println("------------------------------------------------");
		System.out.printf("%-30s %-20s %s\n","TITLE","GENRE","YEAR");
		for (i=0; i<n; i++)
			System.out.printf("%-30s %-20s %4d\n",titles[i],genres[i],years[i]);
	}


	/**
	 * Displays menu and get's user's selection
	 *
	 * @return the user's menu selection
	*/
	public static int getMenuChoice()
	{
		Scanner kb= new Scanner(System.in);
		int choice;	 // user's selection

		System.out.println("\n\n");
		System.out.print("------------------------------------\n");
		System.out.print("[1] Add a Movie\n");
		System.out.print("[2] Delete a Movie\n");
		System.out.print("[3] List All Movies\n");
		System.out.print("[4] Search by Genre\n");
		System.out.print("[5] Search by Title\n");
		System.out.print("[6] Search by Year\n");
		System.out.print("---\n");
		System.out.print("[0] Exit Program\n");
		System.out.print("------------------------------------\n");
		do {
			System.out.print("Your choice: ");
			choice= kb.nextInt();
		} while (choice < 0 || choice > 6);

		return choice;
	}
   
   /**
    * Prompts user to enter a year and displays movies that match that year.
   
    * @param titles array of movie titles
	 * @param genres array of movie genres
	 * @param years array of movie copyright dates
	 * @param n the actual number of movies currently in the array

   
   */
   public static void searchByYear(String [] titles, String [] genres, int [] years, int n)
   {
		Scanner kb= new Scanner(System.in);
		int year; //year to be searched for 
      System.out.println("Search By Year");
      System.out.print("------------------------------------\n");
      System.out.print("Enter year: ");
      year = kb.nextInt();
      for(int i=0; i < years.length - 1; i++)
         if (years[i]==year)
            System.out.printf("%-30s %-20s %4d\n",titles[i],genres[i],years[i]);      
   }


   /**
    * Prompts user to enter a couple of characters and displays movies that match that.
   
    * @param titles array of movie titles
	 * @param genres array of movie genres
	 * @param years array of movie copyright dates
	 * @param n the actual number of movies currently in the array

   
   */   
   public static void searchByTitle(String [] titles, String [] genres, int [] years, int n)
   {
		Scanner kb= new Scanner(System.in);
		String title; //title to be searched for 
      System.out.println("Search By Title");
      System.out.print("------------------------------------\n");
      System.out.print("Enter title: ");
      title = kb.nextLine();
      title.toLowerCase();//converts search term to lowercase to enable case insensitive search
      for(int i=0; i < n; i++){
         if (titles[i].toLowerCase().contains(title)){
            System.out.print(i + ")" + " ");
            System.out.printf("%-30s %-20s %4d\n",titles[i],genres[i],years[i]);
         }
      }      
   }

   /**
    * Prompts user to enter a genre and displays movies that match the genre.
   
    * @param titles array of movie titles
	 * @param genres array of movie genres
	 * @param years array of movie copyright dates
	 * @param n the actual number of movies currently in the array

   
   */
   public static void searchByGenre(String [] titles, String [] genres, int [] years, int n)
   {
		Scanner kb= new Scanner(System.in);
		String genre; //genre to be searched for 
      System.out.println("Search By Genre");
      System.out.print("------------------------------------\n");
      System.out.print("Enter genre: ");
      genre = kb.nextLine();
      genre.toLowerCase();//converts search term to lowercase to enable case insensitive search
      for(int i=0; i < n; i++)
         if (genres[i].toLowerCase().equals(genre))
            System.out.printf("%-30s %-20s %4d\n",titles[i],genres[i],years[i]);      
   }   


	/**
	 * Delete movies from the arrays.
	 *
	 * @param titles array of movie titles
	 * @param genres array of movie genres
	 * @param years array of movie copyright dates
    * @param n the actual number of movies currently in the array

	*/   
   public static void deleteMovie(String [] titles, String [] genres, int [] years, int n)
   {
 	   searchByTitle(titles,genres,years,n);
 		
      Scanner kb= new Scanner(System.in);
      System.out.print("Enter id of item to delete: ");
      int id = kb.nextInt();
      for(int i=id; i<n; i++){
         titles[i] = titles[i+1];
         genres[i] = genres[i+1];
         years[i] = years[i+1];
      }
      n--;         
   }


	/**
	 * Saves changes to the program and effects the changes on the file.
	 *
	 * @param titles array of movie titles
	 * @param genres array of movie genres
	 * @param years array of movie copyright dates
    * @param n the actual number of movies currently in the array

	*/   
   public static void saveChanges(String [] titles, String [] genres, int [] years, int n) throws FileNotFoundException
   {
   PrintStream outfile = new PrintStream("../data/movielist.txt");//opens the file
	int i;
	for (i=0; i<n; i++){
			outfile.println(titles[i]);
         outfile.println(genres[i]);
         outfile.println(years[i]);
   }
   outfile.close();
   }
      
}
 