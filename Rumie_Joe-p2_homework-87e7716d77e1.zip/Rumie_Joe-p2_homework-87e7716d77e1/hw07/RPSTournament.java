/**
 * A Rock, Paper, Scissors Tournament class 
 *
 * @author Ojorumie Joe-Oka
 * @version 3 March 2021
 *
 */

public abstract class RPSTournament extends RPSPlayerContainer
{
   
   /**
    * Constructor to call RPSPlayerContainer constructor 
    */
   public RPSTournament(){
      super();
   }
   

   /**
    * Sorts the players in the container based on their names 
    */
   public void sort(){
      for (int i=0; i<numPlayers-1; i++){
         for(int j=i+1; j<numPlayers; j++){
            if(players[i].compareTo(players[j]) < 0){ 
               RPSPlayer temp = players[i];
               players[i] = players[j];
               players[j] = temp;
            }
         }
      }
   }
   
   public abstract void play();
   
}