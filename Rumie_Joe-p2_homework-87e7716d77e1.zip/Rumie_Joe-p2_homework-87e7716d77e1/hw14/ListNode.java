/**
 * A linked list node holding integer data.
 *
 * @author Ojorumie Joe-Oka
 * @version 28th April 2021
 *
 */
public class ListNode
{
   char data;
   ListNode next;
}