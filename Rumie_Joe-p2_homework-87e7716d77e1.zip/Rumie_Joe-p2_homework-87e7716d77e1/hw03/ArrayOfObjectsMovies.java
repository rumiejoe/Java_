/**
 * Personal Movie Inventory System.
 *
 * @author  Ojorumie Joe-Oka
 * @version 07 February 2021
 *
 * <p>
 * This is the complete code for the parallel array version of the movie
 * inventory system.
 * </p>
 *
*/

import java.util.Scanner;
import java.io.*;

public class ArrayOfObjectsMovies
{
	public static final String DATAFILE= "../data/movielist.txt";
	public static final int MAXMOVIES= 10000;

	public static void main(String [] args) throws FileNotFoundException
	{
		int choice;						 // user's selection from the menu
      Movie [] movies = new Movie[MAXMOVIES];
		int numberOfEntries;
		numberOfEntries= loadMovies(movies);
            

		System.out.println("Number of entries read from data file: "+numberOfEntries);
		do {
			choice= getMenuChoice();
			if (choice==1)
				numberOfEntries= enterMovie(movies,numberOfEntries);
			else if (choice==2){
				deleteMovie(movies,numberOfEntries);
            numberOfEntries--;
			}else if (choice==3)
				displayAll(movies,numberOfEntries);
			else if (choice==4)
				searchByGenre(movies,numberOfEntries);
			else if (choice==5)
				searchByTitle(movies,numberOfEntries);
			else if (choice==6)
				searchByYear(movies,numberOfEntries);
		} while (choice!=0);
      
      saveChanges(movies,numberOfEntries);
		System.out.println("\nTHE END");
	}


	/**
	 * Allow user to enter a new movie.
	 *
	 * @param movies array of movie objects
	 * @param n the actual number of movies currently in the array
	 * @return the new movie count
	*/
	public static int enterMovie(Movie [] movies, int n)
	{
		Scanner kb= new Scanner(System.in);
      
		System.out.print("Enter movie title : ");
		String title = kb.nextLine();
		System.out.print("Enter movie genre: ");
		String genre = kb.nextLine();
		System.out.print("Enter year of movie: ");
		int year = kb.nextInt();
      kb.nextLine();
      movies[n] = new Movie(title,genre,year);
      


		return n+1;
	}




	/**
	 * Load movies into the array from the dat file. 
	 *
	 * @param movies array of movie objects
	*/
	public static int loadMovies(Movie [] movies) throws FileNotFoundException
	{
      int numberOfMovies=0;
      int i =0;
      Scanner fIn = new Scanner(new FileInputStream("../data/movielist.txt"));
      
      while(fIn.hasNextLine()){
         movies[i] = new Movie(fIn.nextLine(),fIn.nextLine(),fIn.nextInt());
         fIn.nextLine();
         
         i+=1;
         numberOfMovies+=1;
      }
      
      
      return numberOfMovies;
	}



	/**
	 * Displays all movie information.
	 *
	 * @param movies array of movie objects
	 * @param n the actual number of movies currently in the array
	*/
	public static void displayAll(Movie [] movies, int n)
	{
		int i;
		System.out.println("------------------------------------------------");
		System.out.printf("%-30s %-20s %s\n","TITLE","GENRE","YEAR");
		for (i=0; i<n; i++)
			System.out.print(movies[i]);
	}


	/**
	 * Displays menu and get's user's selection
	 *
	 * @return the user's menu selection
	*/
	public static int getMenuChoice()
	{
		Scanner kb= new Scanner(System.in);
		int choice;	 // user's selection

		System.out.println("\n\n");
		System.out.print("------------------------------------\n");
		System.out.print("[1] Add a Movie\n");
		System.out.print("[2] Delete a Movie\n");
		System.out.print("[3] List All Movies\n");
		System.out.print("[4] Search by Genre\n");
		System.out.print("[5] Search by Title\n");
		System.out.print("[6] Search by Year\n");
		System.out.print("---\n");
		System.out.print("[0] Exit Program\n");
		System.out.print("------------------------------------\n");
		do {
			System.out.print("Your choice: ");
			choice= kb.nextInt();
		} while (choice < 0 || choice > 6);

		return choice;
	}
   
   /**
    * Prompts user to enter a year and displays movies that match that year.
    *
	 * @param movies array of movie objects
	 * @param n the actual number of movies currently in the array  
   */
   public static void searchByYear(Movie [] movies, int n)
   {
		Scanner kb= new Scanner(System.in);
		int year; //year to be searched for 
      System.out.println("Search By Year");
      System.out.print("------------------------------------\n");
      System.out.print("Enter year: ");
      year = kb.nextInt();
      for(int i=0; i<n; i++)
         if (movies[i].year==year)
            System.out.print(movies[i]);      
   }


   /**
    * Prompts user to enter a couple of characters and displays movies that match that.
	 *
    * @param movies array of movie objects
	 * @param n the actual number of movies currently in the array  
   */   
   public static void searchByTitle(Movie [] movies, int n)
   {
		Scanner kb= new Scanner(System.in);
		String title; //title to be searched for 
      System.out.println("Search By Title");
      System.out.print("------------------------------------\n");
      System.out.print("Enter title: ");
      title = kb.nextLine();
      title = title.toLowerCase();//converts search term to lowercase to enable case insensitive search
      for(int i=0; i < n; i++){
         if (movies[i].title.toLowerCase().contains(title)){
            System.out.print(i + ")" + " ");
            System.out.print(movies[i]);
         }
      }      
   }

   /**
    * Prompts user to enter a genre and displays movies that match the genre.
    *
	 * @param movies array of movie objects
	 * @param n the actual number of movies currently in the array  
   */
   public static void searchByGenre(Movie [] movies, int n)
   {
		Scanner kb= new Scanner(System.in);
		String genre; //genre to be searched for 
      System.out.println("Search By Genre");
      System.out.print("------------------------------------\n");
      System.out.print("Enter genre: ");
      genre = kb.nextLine();
      genre = genre.toLowerCase();//converts search term to lowercase to enable case insensitive search
      for(int i=0; i < n; i++)
         if (movies[i].genre.toLowerCase().equals(genre))
            System.out.print(movies[i]);      
   }   


	/**
	 * Delete movies from the array.
	 *
	 * @param movies array of movie objects
	 * @param n the actual number of movies currently in the array
	*/   
   public static void deleteMovie(Movie [] movies, int n)
   {
 	   searchByTitle(movies,n);
 		
      Scanner kb= new Scanner(System.in);
      System.out.print("Enter id of item to delete: ");
      int id = kb.nextInt();
      for(int i=id; i<n; i++){
         movies[i] = movies[i+1];
      }
      n--;         
   }


	/**
	 * Saves changes to the program and effects the changes on the file.
	 *
	 * @param movies array of movie objects
	 * @param n the actual number of movies currently in the array
	*/   
   public static void saveChanges(Movie [] movies, int n) throws FileNotFoundException
   {
   PrintStream outfile = new PrintStream("../data/movielist.txt");//opens the file
	int i;
	for (i=0; i<n; i++){
			outfile.println(movies[i].title);
			outfile.println(movies[i].genre);
			outfile.println(movies[i].year);

   }
   outfile.close();//closes the file 
   }
      
}
 