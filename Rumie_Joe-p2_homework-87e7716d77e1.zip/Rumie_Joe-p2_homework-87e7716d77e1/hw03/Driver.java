/**
 * Source file 
 *
 * @author  Ojorumie Joe-Oka
 * @version 09 February 2021
 *
 * <p>
 * This is a source file that will work with the Movie class.
 * </p>
 *
*/

public class Driver{
   public static void main(String [] args){
      Movie a;
      Movie b;
      a = new Movie();//calling constructor without parameters
      
      
      b = new Movie("Ruby Sparks","Fantasy",2012);//calling constructor with parameters 
      
      System.out.println(b);
            
   }
}