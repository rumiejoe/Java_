/**
 * Class file for movie inventory.
 *
 * @author  Ojorumie Joe-Oka
 * @version 09 February 2021
 *
 * <p>
 * This is a class file that consists of movie title, genre and year.
 * It also consists of two constructors.
 * </p>
 *
*/


public class Movie{
   String title;
   String genre;
   int year;
   
   
   public Movie(){
      title = "null";
      genre = "null";
      year = 0;
   }
   
   /**
   * A constructor
   *
   * @param title movie title
   * @param genre movie genre
   * @param year movie copyright date  
   */
   public Movie(String title, String genre, int year){
      this.title = title;
      this.genre = genre;
      this.year = year;
   }
   
   /**
   * Overriding the toString method to print in a preferred formatted style
   *
   */
   @Override
   public String toString(){
      return String.format("%-30s %-20s %4d\n",title,genre,year);      
   }
}