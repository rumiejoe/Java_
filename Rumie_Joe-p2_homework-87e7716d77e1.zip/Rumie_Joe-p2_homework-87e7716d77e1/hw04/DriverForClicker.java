/**
 * This driver is for testing the Clicker class.
 *
 * @author Ojorumie Joe-Oka
 * @version 11 February 2021
 *
*/

public class DriverForClicker
{
	public static void main(String [] args)
	{
		Clicker one,two,three;

		System.out.println("Welcome to the Clicker tester");
      one = new Clicker();
      System.out.println(one);
      two = new Clicker(5);
      two.reset();
      System.out.println(two);
      three = new Clicker(7);
      //three.getValue();
      System.out.println(three.getValue());
	}
}

