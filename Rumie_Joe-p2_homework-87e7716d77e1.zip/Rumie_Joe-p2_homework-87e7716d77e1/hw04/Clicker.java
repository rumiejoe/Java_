/**
 * A clicker is used to count things.
 *
 * @author Ojorumie Joe-Oka
 * @version 11 February 2021
 *
*/

public class Clicker
{
   private int value;
   
   public Clicker()
   {
      count();
   }
   
   public Clicker(int n)
   {
      value=n;
   }
   
   
   /**
    * Increment the value of the counter by 1
    */
   public void count()
   {
      value+=1;
   }
   
   /**
    *Reset the value of the counter to zero
    */
   public void reset()
   {
      value = 0;
   }
   
   /**
	 * Show the value of the die if someone prints this object.
	 */
   public String toString()
	{
		return ""+value;
	}
   
   /**
	 * Provides the current value of the clicker as an int.
	 * @return the current value of the clicker
	 */
	public int getValue()
	{
		return value;
	}
}

