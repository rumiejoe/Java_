/**
 * Source file 
 *
 * @author  Ojorumie Joe-Oka
 * @version 09 February 2021
 *
 * <p>
 * This is a source file that will work with the Movie class.
 * </p>
 *
*/
import java.io.*;


public class Driver{
   public static void main(String [] args) throws FileNotFoundException{
      MovieContainer a;
      a = new MovieContainer("../data/tinymovielist.txt");
      //System.out.println("\n");
      a.insert("Up","Fantasy",2005);
      //System.out.println("\n");
      a.insert("Ted","Fantasy",2012);
      //System.out.println("\n");
      a.insert("Baby Driver","Thriller",2017);
      //System.out.println("\n");
      a.display(); 
      System.out.println();
      System.out.print(a.size());
      System.out.println("\n");
      a.searchByTitle("the");
      System.out.println("\n");
      a.searchByGenre("Fantasy");
      System.out.println("\n");
      a.searchByYear(2012);
      System.out.println("\n");
      a.remove(11);
      a.display();
      System.out.println();
      System.out.print(a.size());
      a.save();
      
      
      //System.out.print(numMovies);           
   }
}