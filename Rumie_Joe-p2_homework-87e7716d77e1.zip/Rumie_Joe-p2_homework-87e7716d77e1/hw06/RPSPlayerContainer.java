/**
 * A Rock, Paper, Scissors container that stores players 
 *
 *
 * @author Ojorumie Joe-Oka 
 * @version  26 February 2021 
 *
 *
 */


public class RPSPlayerContainer
{
   
   private RPSPlayer [] players;
   private int numPlayers;
   
   public RPSPlayerContainer(){
      players = new RPSPlayer[100];
   }
   
   public void add(RPSPlayer p){
      players[numPlayers] = p;
      numPlayers++;
   }
   
   public void display(){
      for(int i=0; i<numPlayers; i++){
         System.out.println(players[i]);
      }
   }

}