/**
 * A linked list of string values.
 *
 * @author Ojorumie Joe-Oka 
 * @version 13th April 2021
 *
 */
public class WordList
{
	private WordNode head;

	/**
	 * A new list has head pointing nowhere.
	 */
	public WordList()
	{
		head= null;
	}


	/**
	 * Displays contents of the list.
	 */
	public void display()
	{
      for(WordNode p=head; p!=null; p=p.next){
         System.out.println(p.data);
      }
	}


	/**
	 * In an unordered list we can just add to the front.
	 *
	 * @param newdata The new element to be inserted into the list.
	 */
	public void insert(Word newdata)
	{
      WordNode p = new WordNode();
      p.data = newdata;
      p.next = head;
      head = p;

	}


	/**
	 * Search the list for the value val.
	 *
	 * @param val the value to be searched for
	 * @return reference to the found node (null if not found)
	 */
	/*public WordNode search(Word val)
	{
      WordNode p;
      p = head;
      if(head == null)
         return null;
      else{
          while(p != null  && p.data != val){
            if(p.data == val)
               return p;
            p = p.next;
         }
      }
		return null;
	}


	/**
	 * Find first occurrence of val (if it exists) and remove it from the list.
	 *
	 * @param val the value to be removed
	 */
	/*public void remove(Word val)
	{
      WordNode p,q;
      q = null;
      p = head;
      while(p.data != val){
         q = p;
         p = p.next;
      }
      if(head == null||p==null){
         return;
      }else if(head.data == val){
         head = head.next;
      }else{
         q.next = p.next;
      
      }
	}*/
}
