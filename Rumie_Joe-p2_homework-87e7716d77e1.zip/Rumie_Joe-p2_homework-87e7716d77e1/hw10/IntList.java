/**
 * A linked list of integer values.
 *
<<<<<<< HEAD
 * @author Ojorumie Joe-Oka 
 * @version 13th April 2021
=======
 * @author
 * @version
>>>>>>> 1073affb8b38d006b388952e84e62b6a0c5b0148
 *
 */
public class IntList
{
	private IntNode head;

	/**
	 * A new list has head pointing nowhere.
	 */
	public IntList()
	{
		head= null;
	}


	/**
	 * Displays contents of the list.
	 */
	public void display()
	{
<<<<<<< HEAD
      for(IntNode p=head; p!=null; p=p.next){
         System.out.println(p.data);
      }
=======
>>>>>>> 1073affb8b38d006b388952e84e62b6a0c5b0148
	}


	/**
	 * In an unordered list we can just add to the front.
	 *
	 * @param newdata The new element to be inserted into the list.
	 */
	public void insert(int newdata)
	{
<<<<<<< HEAD
      IntNode p = new IntNode();
      p.data = newdata;
      p.next = head;
      head = p;

=======
>>>>>>> 1073affb8b38d006b388952e84e62b6a0c5b0148
	}


	/**
	 * Search the list for the value val.
	 *
	 * @param val the value to be searched for
	 * @return reference to the found node (null if not found)
	 */
	public IntNode search(int val)
	{
<<<<<<< HEAD
      IntNode p;
      p = head;
      if(head == null)
         return null;
      else{
          while(p != null  && p.data != val){
            if(p.data == val)
               return p;
            p = p.next;
         }
      }
=======

>>>>>>> 1073affb8b38d006b388952e84e62b6a0c5b0148
		return null;
	}


	/**
	 * Find first occurrence of val (if it exists) and remove it from the list.
	 *
	 * @param val the value to be removed
	 */
	public void remove(int val)
	{
<<<<<<< HEAD
      IntNode p,q;
      q = null;
      p = head;
      while(p.data != val){
         q = p;
         p = p.next;
      }
      if(head == null||p==null){
         return;
      }else if(head.data == val){
         head = head.next;
      }else{
         q.next = p.next;
      
      }
=======
>>>>>>> 1073affb8b38d006b388952e84e62b6a0c5b0148
	}
}
