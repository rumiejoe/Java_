/**
 * A linked list node holding string data.
 *
 * @author Ojorumie Joe-Oka
 * @version 13th April 2021
 *
 */
public class WordNode
{
	Word data;
	WordNode next;
}

