/**
 * Driver for testing IntList code.
 *
<<<<<<< HEAD
 * @author Ojorumie Joe-Oka
 * @version 13th April 2021
 *
 */

import java.io.*;

public class Driver
{
	public static void main(String [] args) throws IOException
	{
      WordList list = new WordList();
      Word converter;
      
      BufferedReader br = new BufferedReader(new FileReader("words.txt"));      
      String word = br.readLine();
     
      while (word != null) {
         converter = new Word(word); // Converts the word from type string to type Word 
         list.insert(converter);
         
         word = br.readLine();
	   }     
      br.close();

      list.display();
      
      
=======
 * @author
 * @version
 *
 */

public class Driver
{
	public static void main(String [] args)
	{

>>>>>>> 1073affb8b38d006b388952e84e62b6a0c5b0148
	}
}

