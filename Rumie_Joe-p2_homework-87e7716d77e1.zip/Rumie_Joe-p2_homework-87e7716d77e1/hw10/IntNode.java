/**
 * A linked list node holding integer data.
 *
<<<<<<< HEAD
 * @author Ojorumie Joe-Oka
 * @version 13th April 2021
=======
 * @author
 * @version
>>>>>>> 1073affb8b38d006b388952e84e62b6a0c5b0148
 *
 */
public class IntNode
{
	int data;
	IntNode next;
}

