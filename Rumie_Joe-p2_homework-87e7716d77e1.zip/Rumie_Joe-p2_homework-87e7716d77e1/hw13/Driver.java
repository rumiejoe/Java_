/**
 * Driver for testing classes.
 *
 * @author Ojorumie Joe-Oka
 * @version 21st April 2021
 *
 */

import java.io.*;

public class Driver 
{
	public static void main(String [] args) throws IOException
	{
            
      
      //CodeTimer time = new CodeTimer();     
      
      //time.start();
      ArrayDictionary a = new ArrayDictionary("../hw10/words.txt");
      a.display();
      //time.stop();
      //System.out.print(time);
	}
}

