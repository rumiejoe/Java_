/**
 * Demonstrates use of Java's ArrayList.
 *
 * @author  TSergeant
 * @version for Program Design 2
 */

import java.util.ArrayList;
import java.util.ListIterator;

public class DemoArrayList
{
	public static void main(String [] args)
	{
		/*
      ArrayList<String> al;

		al= new ArrayList<String>();

		al.add("hi");
		al.add("there");
      al.add("re");
		System.out.println(al.size());
      System.out.println(al.indexOf("there"));
		System.out.println(al.get(0));
		System.out.println(al.get(1));
      //al.remove(1);
      System.out.println(al);
      
      String fun; 
      ListIterator<String> it;
      it= al.listIterator(); // assumes sc is ArrayList<String> object that has data 
      while(it.hasNext()){
         fun= it.next();
         System.out.println(fun);
      }
      /*
      fun= it.next();
      System.out.println(fun);
      fun= it.next();
      System.out.println(fun);
      */
      
      
      
      ArrayList<Word> al = new ArrayList<Word>();
      ListIterator<Word> it = al.listIterator();
      Word converter;
      Word fun;
      converter = new Word("well");
      al.add(converter);
      Word convert = new Word("sell");
      al.add(convert);
      converter = new Word("tell");
      al.add(converter);
      converter = new Word("roll");
      al.add(converter);
      
      fun = it.next();
      System.out.print(fun);
      fun = it.next();
      System.out.print(fun);
      fun = it.next();
      System.out.print(fun);
      fun = it.next();
      System.out.print(fun);
      
      /*
      System.out.println(al.size());
      System.out.println(al.indexOf(convert));
		System.out.println(al.get(2));
      al.remove(2);
      */
      
      
      
	}
}
